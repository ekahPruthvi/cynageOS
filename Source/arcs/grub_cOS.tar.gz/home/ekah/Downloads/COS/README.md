# GRUB Seegson theme
## Author: Kristian Oravec
A custom theme inspired by fictional corporation from Alien universe

### Version history:

        0.99: first test release

### Introduction:

        This shall be the default theme for the GRUB2 or GRUB. As the theme format seems to be more stable then before, there is hope that this theme will w>
        in future version of GRUB2 as well.

### Usage:

        The font (c.f. theme.txt) required by this theme are not supplied with it,
        as they should be generated out of the newest available version at compile time.

### Copyright & Licensing:

        Use as you want.

### Screenshot
![seegson](https://github.com/user-attachments/assets/38a0c6be-ca7e-4e30-9de2-e139cfb378a6)
